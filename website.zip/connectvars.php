<?php
  // Define database connection constants
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASSWORD', 'toor');
  define('DB_NAME', 'readersjunction');
  
  ########## Google Settings.. Client ID, Client Secret from https://cloud.google.com/console #############
  $google_client_id		= 	'65285371786-iqs1ironui565sba831i5fj9ddkocl0e';
  $google_client_secret =	'Jhj29fe47M5E7MefUijSMrcD';
  $google_redirect_url 	=	'http://localhost/website/welcome.php'; 
  $google_developer_key	=	'AIzaSyABI-BTWcwOfiWttIo77jE1YxWtQXGSFn4';
  $app_name				= 	'Login to Readers Jumction'

?>
